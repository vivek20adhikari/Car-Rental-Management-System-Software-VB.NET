﻿Partial Class Rent_DetailsDataSet
End Class
